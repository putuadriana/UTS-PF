
<?php $__env->startSection('content'); ?>
    <h2><?php echo e($pageTitle); ?></h2>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pem-framework\UTS - Pemrograman Framework\uts-framework\resources\views/home.blade.php ENDPATH**/ ?>