<?php $__env->startSection('content'); ?>
        <h2> OXIZAL </h2>
        <p> Oxizal yaitu suatu tempat penjualan kendaraan roda dua maupun roda empat yang memiliki kualiatas unggul dan harga terbaik. Oxizal juga menawarkan pelayanan jual beli kendaraan bekas </p>
        <div class="container">
            <div class="row mt-4">
              <div class="col-md-4">
                <div class="card mb-4">
                  <img src="<?php echo e(Vite::asset('resources/images/sepeda.jpeg')); ?>" class="card-img-top" alt="Item 1">
                  <div class="card-body">
                    <h5 class="card-title">Beaufort Bikes</h5>
                    <p class="card-text">Beaufort Bikes merupakan salah satu sepeda elektrik VTC yang baik digunakan untuk sehari-hari.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card mb-4">
                  <img src="<?php echo e(Vite::asset('resources/images/mobil.jpeg')); ?>" class="card-img-top" alt="Item 2">
                  <div class="card-body">
                    <h5 class="card-title">Porsche 911</h5>
                    <p class="card-text">Porche 911 merupakan salah satu mobil sport yang terkenal dan mobil legendaris sepanjang masa.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="card mb-4">
                  <img src="<?php echo e(Vite::asset('resources/images/motor.jpeg')); ?>" class="card-img-top" alt="Item 3">
                  <div class="card-body">
                    <h5 class="card-title">Vespa Primavera</h5>
                    <p class="card-text">Vespa Primavera merupakan salah satu motor yang elegan dan ikonik dan sporty yang untuk digunakan sehari-hari.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>`
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Music\uts-framework\resources\views/home.blade.php ENDPATH**/ ?>