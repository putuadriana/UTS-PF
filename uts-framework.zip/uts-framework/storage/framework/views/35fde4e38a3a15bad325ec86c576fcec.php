 <?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2><?php echo e($pageTitle); ?></h2>

    <div class="row">
        <div class="col-lg-4">
            <div class="card mb-4">
              <div class="card-body text-center">
                <img
                  src="<?php echo e(Vite::asset('resources/images/ini saya.jpeg')); ?>"
                  alt="avatar"
                  class="img-fluid"
                  style="width: 200px"
                />
              </div>
            </div>
          </div>
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-3">
                            <p class="mb-0 text-start">Name</p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted mb-0 text-start">
                            Ni Putu Adriana Swastika Yoga
                            </p>
                        </div>
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-sm-3">
                            <p class="mb-0 text-start">Email</p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted mb-0 text-start">
                                niputuadriana@gmail.com
                            </p>
                        </div>
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-sm-3">
                            <p class="mb-0 text-start">Phone</p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted mb-0 text-start">
                                +6281229196820
                            </p>
                        </div>
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-sm-3">
                            <p class="mb-0 text-start">Instagram</p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted mb-0 text-start">
                                @aanairdautup
                            </p>
                        </div>
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-sm-3">
                            <p class="mb-0 text-start">Address</p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted mb-0 text-start">
                                Surabaya, East Java
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ACER\Music\uts-framework\resources\views/profile.blade.php ENDPATH**/ ?>