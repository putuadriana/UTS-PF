<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BarangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('barangs')->insert([
            'kode_barang' => '010200',
            'nama_barang' => 'Mobil',
            'harga_barang' => 85000000,
            'deskripsi_barang' => 'Mobil keren dan nyaman untuk berpergian',
            'satuan_id' => 2,
        ]);
    }
}
