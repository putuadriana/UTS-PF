<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SatuanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('satuans')->insert([
            [
                'kode_satuan' => '001100',
                'nama_satuan' => '500gram'
            ],
            [
                'kode_satuan' => '001200',
                'nama_satuan' => '1500 kilogram'
            ],
            [
                'kode_satuan' => '001300',
                'nama_satuan' => '145 kilogram'
            ],
        ]);
    }
}
