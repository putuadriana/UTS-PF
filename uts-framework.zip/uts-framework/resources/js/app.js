import './bootstrap';
import "bootstrap-icons/font/bootstrap-icons.css";
import.meta.glob(["../images/**"]);
